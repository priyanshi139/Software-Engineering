
import React, { useState } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import PlanningFlow from './components/PlanningFlow';
import VendorBazaar from './components/VendorBazaar';
import BudgetTracker from './components/BudgetTracker';
import Countdown from './components/Countdown';
import Footer from './components/Footer';
import AuthModal from './components/AuthModal';
import VendorDashboard from './components/dashboards/VendorDashboard';
import UserDashboard from './components/dashboards/UserDashboard';
import AdminDashboard from './components/dashboards/AdminDashboard';
import RoleSwitcher from './components/RoleSwitcher';

export type UserRole = 'guest' | 'user' | 'vendor' | 'admin';
export type AppView = 'home' | 'vendors' | 'budget' | 'dashboard';

const App: React.FC = () => {
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<AppView>('home');
  const [currentRole, setCurrentRole] = useState<UserRole>('guest');

  const renderDashboard = () => {
    switch (currentRole) {
      case 'vendor':
        return <VendorDashboard />;
      case 'user':
        return <UserDashboard />;
      case 'admin':
        return <AdminDashboard />;
      default:
        return <Hero onExplore={() => setActiveTab('vendors')} />;
    }
  };

  const renderContent = () => {
    if (activeTab === 'dashboard') {
      return renderDashboard();
    }

    switch (activeTab) {
      case 'home':
        return (
          <>
            <Hero onExplore={() => setActiveTab('vendors')} />
            <Countdown />
            <PlanningFlow />
            <div className="bg-white py-16 px-4">
              <div className="max-w-7xl mx-auto text-center">
                <h2 className="text-3xl md:text-4xl font-serif text-maroon mb-4">Handpicked Vendors</h2>
                <p className="text-gray-600 mb-12">Only the finest for your Big Day. Every vendor carries our "Bharosa" seal.</p>
                <VendorBazaar limit={4} />
                <button 
                  onClick={() => setActiveTab('vendors')}
                  className="mt-12 px-8 py-3 bg-maroon text-white rounded-full font-medium hover:bg-opacity-90 transition-all shadow-lg"
                >
                  View All Vendors
                </button>
              </div>
            </div>
          </>
        );
      case 'vendors':
        return (
          <div className="pt-24 pb-16 min-h-screen">
            <div className="max-w-7xl mx-auto px-4">
              <h1 className="text-4xl font-serif text-maroon mb-8 text-center">The Vendor Bazaar</h1>
              <VendorBazaar />
            </div>
          </div>
        );
      case 'budget':
        return (
          <div className="pt-24 pb-16 min-h-screen">
            <div className="max-w-4xl mx-auto px-4">
              <h1 className="text-4xl font-serif text-maroon mb-8 text-center">Shagun Budget Tracker</h1>
              <BudgetTracker />
            </div>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen font-sans selection:bg-saffron selection:text-white">
      <Navbar 
        onAuthClick={() => setIsAuthOpen(true)} 
        activeTab={activeTab} 
        setActiveTab={(tab) => setActiveTab(tab as AppView)} 
        currentRole={currentRole}
      />
      
      <main>
        {renderContent()}
      </main>

      {activeTab !== 'dashboard' && <Footer />}

      <AuthModal isOpen={isAuthOpen} onClose={() => setIsAuthOpen(false)} />
      
      <RoleSwitcher 
        currentRole={currentRole} 
        onRoleChange={(role) => {
          setCurrentRole(role);
          if (role !== 'guest') setActiveTab('dashboard');
          else setActiveTab('home');
        }} 
      />
    </div>
  );
};

export default App;
