
export enum VendorCategory {
  CATERING = 'Catering',
  PHOTOGRAPHY = 'Photography',
  MAKEUP = 'Makeup Artist',
  VENUE = 'Venue',
  DECOR = 'Decor'
}

export interface Vendor {
  id: string;
  name: string;
  category: VendorCategory;
  rating: number;
  reviews: number;
  location: string;
  priceRange: string;
  image: string;
  isVerified: boolean; // Bharosa Badge
  specialty?: string;
  thaliPrice?: string; // Specific for Catering
}

export interface BudgetCategory {
  name: string;
  allocated: number; // in Lakhs
  spent: number; // in Lakhs
}

export interface UserWeddingProfile {
  partnerName: string;
  weddingDate: string;
  location: string;
  totalBudget: number; // in Lakhs
}
