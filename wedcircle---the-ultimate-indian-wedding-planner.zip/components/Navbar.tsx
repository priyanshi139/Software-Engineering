
import React, { useState } from 'react';
import { Menu, X, User, Heart, LayoutDashboard } from 'lucide-react';
import { UserRole } from '../App';

interface NavbarProps {
  onAuthClick: () => void;
  activeTab: string;
  setActiveTab: (tab: any) => void;
  currentRole: UserRole;
}

const Navbar: React.FC<NavbarProps> = ({ onAuthClick, activeTab, setActiveTab, currentRole }) => {
  const [isOpen, setIsOpen] = useState(false);

  const navItems = [
    { id: 'home', label: 'Shaadi Home' },
    { id: 'vendors', label: 'Vendor Bazaar' },
    { id: 'budget', label: 'Shagun Tracker' },
  ];

  return (
    <nav className="fixed w-full z-50 bg-cream/95 backdrop-blur-sm border-b border-saffron/20 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          <div className="flex items-center cursor-pointer" onClick={() => setActiveTab('home')}>
            <div className="w-10 h-10 bg-maroon rounded-full flex items-center justify-center mr-3 shadow-inner">
              <Heart className="text-saffron w-6 h-6 fill-current" />
            </div>
            <span className="text-2xl font-serif font-bold text-maroon tracking-tight">
              Wed<span className="text-saffron">Circle</span>
            </span>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`text-sm font-medium tracking-wide transition-colors ${
                  activeTab === item.id ? 'text-maroon font-semibold border-b-2 border-saffron pb-1' : 'text-gray-600 hover:text-maroon'
                }`}
              >
                {item.label}
              </button>
            ))}
            
            {currentRole !== 'guest' && (
              <button
                onClick={() => setActiveTab('dashboard')}
                className={`flex items-center space-x-2 text-sm font-medium tracking-wide transition-colors ${
                  activeTab === 'dashboard' ? 'text-maroon font-semibold border-b-2 border-saffron pb-1' : 'text-gray-600 hover:text-maroon'
                }`}
              >
                <LayoutDashboard size={16} />
                <span>My Dashboard</span>
              </button>
            )}

            <button
              onClick={onAuthClick}
              className="flex items-center space-x-2 bg-maroon text-white px-5 py-2 rounded-full text-sm font-medium hover:bg-opacity-90 transition-all shadow-md"
            >
              <User size={18} />
              <span>{currentRole === 'guest' ? 'Login / OTP' : 'My Account'}</span>
            </button>
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden flex items-center">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="text-maroon focus:outline-none"
            >
              {isOpen ? <X size={28} /> : <Menu size={28} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Navigation */}
      {isOpen && (
        <div className="md:hidden bg-cream border-t border-saffron/10 px-4 pt-2 pb-6 space-y-2 shadow-xl animate-in fade-in slide-in-from-top-4">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => {
                setActiveTab(item.id);
                setIsOpen(false);
              }}
              className="block w-full text-left px-3 py-3 text-base font-medium text-gray-700 hover:bg-maroon hover:text-white rounded-lg transition-all"
            >
              {item.label}
            </button>
          ))}
          {currentRole !== 'guest' && (
             <button
              onClick={() => {
                setActiveTab('dashboard');
                setIsOpen(false);
              }}
              className="block w-full text-left px-3 py-3 text-base font-medium text-gray-700 hover:bg-maroon hover:text-white rounded-lg transition-all"
            >
              My Dashboard
            </button>
          )}
          <button
            onClick={() => {
              onAuthClick();
              setIsOpen(false);
            }}
            className="block w-full text-center mt-4 bg-maroon text-white py-3 rounded-lg font-medium shadow-md"
          >
            {currentRole === 'guest' ? 'Sign In with OTP' : 'Account Settings'}
          </button>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
