
import React, { useState } from 'react';
import { Star, ShieldCheck, Share2, MapPin } from 'lucide-react';
import { SAMPLE_VENDORS } from '../constants';
import { VendorCategory } from '../types';

interface VendorBazaarProps {
  limit?: number;
}

const VendorBazaar: React.FC<VendorBazaarProps> = ({ limit }) => {
  const vendors = limit ? SAMPLE_VENDORS.slice(0, limit) : SAMPLE_VENDORS;
  const [filter, setFilter] = useState<string>('All');

  const categories = ['All', ...Object.values(VendorCategory)];

  const handleWhatsAppShare = (vendorName: string) => {
    const text = `Hey! I found this amazing vendor on WedCircle for the wedding: ${vendorName}. What do you think?`;
    window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, '_blank');
  };

  return (
    <div className="space-y-8">
      {!limit && (
        <div className="flex flex-wrap gap-3 justify-center mb-10">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setFilter(cat)}
              className={`px-6 py-2 rounded-full text-sm font-medium transition-all ${
                filter === cat ? 'bg-maroon text-white shadow-md' : 'bg-white text-maroon border border-maroon/20 hover:border-maroon'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
        {vendors.map((vendor) => (
          <div 
            key={vendor.id} 
            className="group bg-white rounded-3xl overflow-hidden shadow-sm hover:shadow-2xl transition-all duration-500 border border-cream hover:-translate-y-2"
          >
            <div className="relative h-64 overflow-hidden">
              <img 
                src={vendor.image} 
                alt={vendor.name} 
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
              />
              <div className="absolute top-4 right-4 space-x-2">
                {vendor.isVerified && (
                  <span className="bg-green-600 text-white px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest flex items-center shadow-lg">
                    <ShieldCheck size={12} className="mr-1" /> Bharosa
                  </span>
                )}
              </div>
              <div className="absolute bottom-4 left-4">
                <span className="bg-maroon/80 backdrop-blur-md text-white px-3 py-1 rounded-md text-[10px] font-medium">
                  {vendor.category}
                </span>
              </div>
            </div>

            <div className="p-6">
              <div className="flex justify-between items-start mb-2">
                <h3 className="text-xl font-serif font-bold text-gray-900 group-hover:text-maroon transition-colors line-clamp-1">{vendor.name}</h3>
                <div className="flex items-center text-saffron font-bold text-sm">
                  <Star size={14} className="fill-current mr-1" />
                  {vendor.rating}
                </div>
              </div>
              
              <div className="flex items-center text-gray-500 text-sm mb-4">
                <MapPin size={14} className="mr-1 text-maroon" />
                {vendor.location}
              </div>

              <div className="flex items-center justify-between pt-4 border-t border-gray-100">
                <div>
                  <p className="text-[10px] text-gray-400 uppercase font-bold tracking-widest">Pricing</p>
                  <p className="text-lg font-bold text-gray-900">{vendor.thaliPrice || vendor.priceRange}</p>
                </div>
                <button 
                  onClick={() => handleWhatsAppShare(vendor.name)}
                  className="p-3 bg-green-50 text-green-600 rounded-full hover:bg-green-600 hover:text-white transition-all shadow-inner"
                  title="Share on WhatsApp"
                >
                  <Share2 size={18} />
                </button>
              </div>

              <button className="w-full mt-6 py-3 border-2 border-maroon text-maroon font-bold rounded-xl hover:bg-maroon hover:text-white transition-all text-sm tracking-wide active:scale-95">
                Check Availability
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default VendorBazaar;
