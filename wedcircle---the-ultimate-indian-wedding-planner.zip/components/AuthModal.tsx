
import React, { useState } from 'react';
import { X, Smartphone, CheckCircle2 } from 'lucide-react';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const AuthModal: React.FC<AuthModalProps> = ({ isOpen, onClose }) => {
  const [step, setStep] = useState<'phone' | 'otp'>('phone');
  const [phone, setPhone] = useState('');

  if (!isOpen) return null;

  const handleSendOTP = (e: React.FormEvent) => {
    e.preventDefault();
    if (phone.length === 10) setStep('otp');
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-maroon/60 backdrop-blur-sm" onClick={onClose}></div>
      
      <div className="relative bg-cream w-full max-w-md rounded-[32px] overflow-hidden shadow-2xl animate-in zoom-in-95 duration-200">
        <button 
          onClick={onClose}
          className="absolute top-6 right-6 p-2 text-maroon hover:bg-maroon hover:text-white rounded-full transition-all"
        >
          <X size={20} />
        </button>

        <div className="h-2 bg-gradient-to-right from-maroon via-saffron to-maroon"></div>

        <div className="p-10">
          <div className="text-center mb-10">
            <div className="w-16 h-16 bg-maroon/5 rounded-2xl flex items-center justify-center mx-auto mb-6">
              <Smartphone className="text-maroon w-8 h-8" />
            </div>
            <h2 className="text-3xl font-serif font-bold text-maroon mb-2">
              {step === 'phone' ? 'Namaste!' : 'Verify OTP'}
            </h2>
            <p className="text-gray-500 text-sm">
              {step === 'phone' 
                ? 'Login to start your planning journey.' 
                : `We've sent a 6-digit code to +91 ${phone}`}
            </p>
          </div>

          <form onSubmit={handleSendOTP} className="space-y-6">
            {step === 'phone' ? (
              <div className="space-y-4">
                <div className="relative">
                  <span className="absolute left-4 top-1/2 -translate-y-1/2 font-bold text-maroon/50">+91</span>
                  <input 
                    type="tel" 
                    required
                    maxLength={10}
                    value={phone}
                    onChange={(e) => setPhone(e.target.value.replace(/\D/g, ''))}
                    placeholder="Enter Phone Number" 
                    className="w-full bg-white border border-gray-200 rounded-2xl py-4 pl-14 pr-4 focus:ring-2 focus:ring-maroon/20 focus:border-maroon outline-none transition-all"
                  />
                </div>
                <button 
                  type="submit"
                  className="w-full py-4 bg-maroon text-white font-bold rounded-2xl shadow-lg shadow-maroon/20 hover:scale-[1.02] active:scale-95 transition-all"
                >
                  Send OTP
                </button>
              </div>
            ) : (
              <div className="space-y-6">
                <div className="flex justify-between gap-2">
                  {[1, 2, 3, 4, 5, 6].map((i) => (
                    <input 
                      key={i}
                      type="text" 
                      maxLength={1}
                      className="w-full h-14 text-center text-xl font-bold bg-white border border-gray-200 rounded-xl focus:ring-2 focus:ring-saffron outline-none"
                    />
                  ))}
                </div>
                <button 
                  type="button"
                  onClick={onClose}
                  className="w-full py-4 bg-saffron text-maroon font-black rounded-2xl shadow-lg active:scale-95 transition-all uppercase tracking-widest text-xs"
                >
                  Enter WedCircle
                </button>
                <button 
                  type="button"
                  onClick={() => setStep('phone')}
                  className="w-full text-center text-xs text-gray-400 font-medium hover:text-maroon transition-colors"
                >
                  Change Phone Number
                </button>
              </div>
            )}
          </form>

          <div className="mt-10 pt-8 border-t border-gray-100 flex items-center justify-center text-[10px] text-gray-400 uppercase tracking-widest font-bold">
            <CheckCircle2 size={12} className="mr-1 text-green-500" /> Secure • Encrypted • Safe
          </div>
        </div>
      </div>
    </div>
  );
};

export default AuthModal;
