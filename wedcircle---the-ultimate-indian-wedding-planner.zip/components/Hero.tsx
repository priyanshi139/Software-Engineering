
import React from 'react';
import { Search, MapPin, Sparkles } from 'lucide-react';

interface HeroProps {
  onExplore: () => void;
}

const Hero: React.FC<HeroProps> = ({ onExplore }) => {
  return (
    <div className="relative h-[90vh] flex items-center justify-center overflow-hidden">
      {/* Background with Overlay */}
      <div 
        className="absolute inset-0 z-0"
        style={{
          backgroundImage: 'url("https://images.unsplash.com/photo-1511795409834-ef04bbd61622?w=1600&q=80")',
          backgroundSize: 'cover',
          backgroundPosition: 'center'
        }}
      >
        <div className="absolute inset-0 bg-maroon/40 backdrop-blur-[1px]"></div>
      </div>

      <div className="relative z-10 text-center px-4 max-w-5xl mx-auto text-white">
        <div className="inline-flex items-center space-x-2 bg-saffron/20 backdrop-blur-md px-4 py-1.5 rounded-full border border-saffron/30 mb-8 animate-bounce">
          <Sparkles className="text-saffron w-4 h-4" />
          <span className="text-xs md:text-sm font-medium tracking-widest uppercase">Planning the Perfect Indian Shaadi</span>
        </div>
        
        <h1 className="text-5xl md:text-7xl lg:text-8xl font-serif font-bold mb-6 leading-tight drop-shadow-lg">
          Your Fairytale <br />
          <span className="italic text-saffron">Begins Here</span>
        </h1>
        
        <p className="text-lg md:text-xl font-light mb-12 max-w-2xl mx-auto opacity-90 leading-relaxed">
          From the Baraat to the Bidaai, find the best venues, caterers, and artists across India.
        </p>

        {/* Search Bar - Bespoke UI */}
        <div className="bg-white p-2 md:p-3 rounded-2xl md:rounded-full shadow-2xl flex flex-col md:flex-row items-center max-w-3xl mx-auto space-y-4 md:space-y-0 md:space-x-4">
          <div className="flex-1 flex items-center px-4 w-full border-b md:border-b-0 md:border-r border-gray-100 py-2">
            <Search className="text-maroon mr-3" size={20} />
            <input 
              type="text" 
              placeholder="Searching for photographers, venues...?" 
              className="w-full focus:outline-none text-gray-800 text-sm md:text-base placeholder:text-gray-400"
            />
          </div>
          <div className="flex-1 flex items-center px-4 w-full py-2">
            <MapPin className="text-maroon mr-3" size={20} />
            <select className="w-full focus:outline-none text-gray-800 text-sm md:text-base bg-transparent appearance-none">
              <option>All Cities</option>
              <option>Delhi NCR</option>
              <option>Mumbai</option>
              <option>Bangalore</option>
              <option>Jaipur</option>
            </select>
          </div>
          <button 
            onClick={onExplore}
            className="w-full md:w-auto px-10 py-4 bg-maroon text-white rounded-xl md:rounded-full font-bold text-sm tracking-wider uppercase hover:bg-saffron transition-all shadow-lg active:scale-95"
          >
            Explore Bazaar
          </button>
        </div>

        <div className="mt-12 flex flex-wrap justify-center gap-6 opacity-70 grayscale hover:grayscale-0 transition-all">
          <span className="text-xs uppercase tracking-tighter">Featured In: WeddingSutra • Vogue Weddings • Femina</span>
        </div>
      </div>
    </div>
  );
};

export default Hero;
