
import React from 'react';

const Countdown: React.FC = () => {
  return (
    <div className="bg-maroon py-10 px-4 relative overflow-hidden">
      {/* Decorative Mandap Pattern (Simulated) */}
      <div className="absolute top-0 left-0 w-full h-full opacity-5 pointer-events-none bg-[radial-gradient(#FBBF24_1px,transparent_1px)] [background-size:20px_20px]"></div>

      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-8 relative z-10">
        <div className="text-center md:text-left">
          <h2 className="text-2xl md:text-3xl font-serif text-white mb-1">Aryan & Saanvi's</h2>
          <p className="text-saffron font-bold tracking-widest uppercase text-sm">Grand Celebration in Udaipur</p>
        </div>

        <div className="flex gap-4 md:gap-8">
          {[
            { label: 'Days', val: '124' },
            { label: 'Hrs', val: '08' },
            { label: 'Mins', val: '45' },
            { label: 'Secs', val: '12' }
          ].map((item, idx) => (
            <div key={idx} className="flex flex-col items-center">
              <div className="bg-white/10 backdrop-blur-md w-16 h-16 md:w-20 md:h-20 rounded-2xl flex items-center justify-center border border-white/20 shadow-xl">
                <span className="text-2xl md:text-4xl font-serif font-bold text-white">{item.val}</span>
              </div>
              <span className="text-[10px] md:text-xs text-saffron mt-2 font-bold uppercase tracking-widest">{item.label}</span>
            </div>
          ))}
        </div>

        <button className="px-8 py-3 bg-saffron text-maroon font-black rounded-full text-xs tracking-tighter uppercase shadow-lg hover:bg-white transition-all whitespace-nowrap">
          Edit Details
        </button>
      </div>
    </div>
  );
};

export default Countdown;
