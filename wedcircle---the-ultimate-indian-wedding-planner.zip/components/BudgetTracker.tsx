
import React, { useState } from 'react';
import { IndianRupee, PieChart, TrendingUp, AlertCircle } from 'lucide-react';

const BudgetTracker: React.FC = () => {
  const [totalBudget, setTotalBudget] = useState(25); // in Lakhs
  const categories = [
    { name: 'Venue & Stay', allocated: 10, spent: 4 },
    { name: 'Catering', allocated: 6, spent: 1 },
    { name: 'Decor', allocated: 3, spent: 0 },
    { name: 'Photography', allocated: 2.5, spent: 2.5 },
    { name: 'Outfits & Jewelry', allocated: 3.5, spent: 0.5 }
  ];

  const totalSpent = categories.reduce((acc, cat) => acc + cat.spent, 0);
  const remaining = totalBudget - totalSpent;

  return (
    <div className="bg-white rounded-3xl p-8 shadow-xl border border-saffron/10">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 mb-10">
        <div>
          <h2 className="text-2xl font-serif font-bold text-maroon flex items-center">
            <PieChart className="mr-2" /> Wedding Financial Dashboard
          </h2>
          <p className="text-gray-500">Manage your Shagun and expenses across categories.</p>
        </div>
        <div className="bg-cream px-6 py-3 rounded-2xl border-2 border-saffron/20 text-center">
          <p className="text-xs text-gray-500 uppercase font-bold tracking-widest">Target Budget</p>
          <div className="flex items-center justify-center">
            <span className="text-2xl font-bold text-maroon">₹ {totalBudget} Lakhs</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
        <div className="bg-green-50 p-6 rounded-2xl border-l-4 border-green-500">
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm text-green-800 font-medium">Spent so far</span>
            <TrendingUp size={20} className="text-green-500" />
          </div>
          <p className="text-2xl font-bold text-green-700">₹ {totalSpent} Lakhs</p>
        </div>
        <div className="bg-saffron/10 p-6 rounded-2xl border-l-4 border-saffron">
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm text-saffron font-medium">Remaining</span>
            <IndianRupee size={20} className="text-saffron" />
          </div>
          <p className="text-2xl font-bold text-saffron">₹ {remaining} Lakhs</p>
        </div>
        <div className="bg-maroon/5 p-6 rounded-2xl border-l-4 border-maroon">
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm text-maroon font-medium">Commitments</span>
            <AlertCircle size={20} className="text-maroon" />
          </div>
          <p className="text-2xl font-bold text-maroon">₹ {totalBudget} Lakhs</p>
        </div>
      </div>

      <div className="space-y-6">
        <h3 className="font-bold text-gray-800 border-b border-gray-100 pb-2">Expense Breakdown</h3>
        {categories.map((cat, idx) => (
          <div key={idx} className="space-y-2">
            <div className="flex justify-between text-sm">
              <span className="font-medium text-gray-700">{cat.name}</span>
              <span className="text-gray-500">₹{cat.spent} / ₹{cat.allocated} Lakhs</span>
            </div>
            <div className="w-full h-3 bg-gray-100 rounded-full overflow-hidden">
              <div 
                className="h-full bg-maroon transition-all duration-1000" 
                style={{ width: `${(cat.spent / cat.allocated) * 100}%` }}
              ></div>
            </div>
          </div>
        ))}
      </div>

      <button className="w-full mt-10 py-4 bg-maroon text-white font-bold rounded-2xl shadow-lg shadow-maroon/20 hover:scale-[1.02] transition-transform">
        Download Detailed Estimate (PDF)
      </button>
    </div>
  );
};

export default BudgetTracker;
