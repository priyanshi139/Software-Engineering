
import React from 'react';
import { UserRole } from '../App';
import { Settings } from 'lucide-react';

interface RoleSwitcherProps {
  currentRole: UserRole;
  onRoleChange: (role: UserRole) => void;
}

const RoleSwitcher: React.FC<RoleSwitcherProps> = ({ currentRole, onRoleChange }) => {
  return (
    <div className="fixed bottom-6 right-6 z-[200] group">
      <div className="bg-white p-2 rounded-2xl shadow-2xl border border-saffron/20 flex flex-col items-end">
        <div className="flex items-center space-x-2 px-3 py-1 mb-2">
          <Settings className="text-saffron w-4 h-4 animate-spin-slow" />
          <span className="text-[10px] font-bold uppercase tracking-widest text-gray-400">Dev Switcher</span>
        </div>
        <div className="flex space-x-1">
          {(['guest', 'user', 'vendor', 'admin'] as UserRole[]).map((role) => (
            <button
              key={role}
              onClick={() => onRoleChange(role)}
              className={`px-3 py-1.5 rounded-xl text-[10px] font-bold uppercase tracking-tighter transition-all ${
                currentRole === role 
                ? 'bg-maroon text-white shadow-lg scale-105' 
                : 'bg-cream text-maroon hover:bg-saffron/10'
              }`}
            >
              {role}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default RoleSwitcher;
