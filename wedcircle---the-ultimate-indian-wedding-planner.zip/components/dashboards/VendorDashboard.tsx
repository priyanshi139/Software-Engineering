
import React, { useState } from 'react';
import { Store, CalendarRange, BarChart3, Settings, ClipboardList, Camera } from 'lucide-react';
import DashboardSidebar, { SidebarItem } from './DashboardSidebar';
import BookingTable from './vendor/BookingTable';
import PortfolioEditor from './vendor/PortfolioEditor';

const VENDOR_NAV_ITEMS: SidebarItem[] = [
  { id: 'bookings', label: 'Booking Requests', icon: CalendarRange },
  { id: 'portfolio', label: 'My Portfolio', icon: Camera },
  { id: 'analytics', label: 'Business Stats', icon: BarChart3 },
  { id: 'services', label: 'Service Catalog', icon: ClipboardList },
  { id: 'settings', label: 'Profile Settings', icon: Settings },
];

const VendorDashboard: React.FC = () => {
  const [activeTab, setActiveTab] = useState('bookings');

  const renderContent = () => {
    switch (activeTab) {
      case 'bookings':
        return <BookingTable />;
      case 'portfolio':
        return <PortfolioEditor />;
      default:
        return (
          <div className="p-12 text-center">
            <h2 className="text-2xl font-serif text-maroon mb-4 capitalize">{activeTab} Section</h2>
            <p className="text-gray-500">This module is coming soon to your WedCircle Partner Suite.</p>
            <div className="mt-8 flex justify-center">
               <div className="animate-pulse w-32 h-1 bg-saffron rounded-full"></div>
            </div>
          </div>
        );
    }
  };

  return (
    <div className="pt-20 bg-cream min-h-screen flex flex-col lg:flex-row">
      <DashboardSidebar 
        items={VENDOR_NAV_ITEMS} 
        activeItem={activeTab} 
        setActiveItem={setActiveTab} 
        title="Vendor Partner" 
        roleIcon={Store}
      />
      <div className="flex-1 overflow-y-auto bg-gray-50/50">
        <div className="max-w-6xl mx-auto p-6 lg:p-12">
          {renderContent()}
        </div>
      </div>
    </div>
  );
};

export default VendorDashboard;
