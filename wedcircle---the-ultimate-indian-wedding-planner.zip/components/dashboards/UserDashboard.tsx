
import React, { useState } from 'react';
import { Heart, Calendar, IndianRupee, MapPin, Gift, Bell } from 'lucide-react';
import DashboardSidebar, { SidebarItem } from './DashboardSidebar';
import BudgetTracker from '../BudgetTracker';
import Countdown from '../Countdown';

const USER_NAV_ITEMS: SidebarItem[] = [
  { id: 'overview', label: 'Wedding Overview', icon: Heart },
  { id: 'budget', label: 'Shagun Tracker', icon: IndianRupee },
  { id: 'wishlist', label: 'Saved Vendors', icon: Gift },
  { id: 'events', label: 'Event Schedule', icon: Calendar },
  { id: 'notifications', label: 'Updates', icon: Bell },
];

const UserDashboard: React.FC = () => {
  const [activeTab, setActiveTab] = useState('overview');

  const renderContent = () => {
    switch (activeTab) {
      case 'overview':
        return (
          <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
            <Countdown />
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
               <div className="bg-white p-8 rounded-[32px] shadow-xl border border-cream">
                  <h3 className="text-xl font-serif font-bold text-maroon mb-6">Wedding Details</h3>
                  <div className="space-y-4">
                    <div className="flex items-center space-x-4 p-4 bg-cream/30 rounded-2xl">
                       <Heart className="text-saffron" />
                       <div>
                         <p className="text-[10px] font-bold uppercase text-gray-400">Partner</p>
                         <p className="font-bold">Saanvi Kapoor</p>
                       </div>
                    </div>
                    <div className="flex items-center space-x-4 p-4 bg-cream/30 rounded-2xl">
                       <MapPin className="text-saffron" />
                       <div>
                         <p className="text-[10px] font-bold uppercase text-gray-400">Destination</p>
                         <p className="font-bold">The Leela Palace, Udaipur</p>
                       </div>
                    </div>
                  </div>
               </div>
               <div className="bg-white p-8 rounded-[32px] shadow-xl border border-cream">
                  <h3 className="text-xl font-serif font-bold text-maroon mb-6">Saved Vendors</h3>
                  <p className="text-gray-500 text-sm mb-6">You have 4 vendors saved for review.</p>
                  <button className="w-full py-4 bg-maroon text-white rounded-2xl font-bold text-sm hover:scale-[1.02] transition-all">
                    Browse saved vendors
                  </button>
               </div>
            </div>
          </div>
        );
      case 'budget':
        return <BudgetTracker />;
      default:
        return (
          <div className="p-12 text-center bg-white rounded-[32px] border border-cream">
            <h2 className="text-2xl font-serif text-maroon mb-4">Shubh Aarambh!</h2>
            <p className="text-gray-500">This feature is being perfected for your dream wedding.</p>
          </div>
        );
    }
  };

  return (
    <div className="pt-20 bg-cream min-h-screen flex flex-col lg:flex-row">
      <DashboardSidebar 
        items={USER_NAV_ITEMS} 
        activeItem={activeTab} 
        setActiveItem={setActiveTab} 
        title="Our Wedding" 
        roleIcon={Heart}
      />
      <div className="flex-1 overflow-y-auto bg-gray-50/50">
        <div className="max-w-6xl mx-auto p-6 lg:p-12">
          {renderContent()}
        </div>
      </div>
    </div>
  );
};

export default UserDashboard;
