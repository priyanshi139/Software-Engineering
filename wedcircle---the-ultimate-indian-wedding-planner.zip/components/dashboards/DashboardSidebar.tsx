
import React from 'react';
import { LucideIcon } from 'lucide-react';

export interface SidebarItem {
  id: string;
  label: string;
  icon: LucideIcon;
}

interface DashboardSidebarProps {
  items: SidebarItem[];
  activeItem: string;
  setActiveItem: (id: string) => void;
  title: string;
  roleIcon: LucideIcon;
}

const DashboardSidebar: React.FC<DashboardSidebarProps> = ({ items, activeItem, setActiveItem, title, roleIcon: RoleIcon }) => {
  return (
    <div className="w-full lg:w-72 bg-white border-r border-saffron/10 h-auto lg:h-[calc(100vh-80px)] overflow-y-auto">
      <div className="p-8">
        <div className="flex items-center space-x-3 mb-10">
          <div className="p-2 bg-maroon rounded-xl shadow-lg">
            <RoleIcon className="text-saffron w-6 h-6" />
          </div>
          <div>
            <h3 className="font-serif font-bold text-maroon text-lg">{title}</h3>
            <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest">Control Center</p>
          </div>
        </div>

        <nav className="space-y-2">
          {items.map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveItem(item.id)}
              className={`w-full flex items-center space-x-4 px-4 py-3 rounded-2xl transition-all duration-300 ${
                activeItem === item.id 
                ? 'bg-maroon text-white shadow-xl translate-x-1' 
                : 'text-gray-500 hover:bg-maroon/5 hover:text-maroon'
              }`}
            >
              <item.icon size={20} className={activeItem === item.id ? 'text-saffron' : 'text-inherit'} />
              <span className="text-sm font-semibold">{item.label}</span>
            </button>
          ))}
        </nav>
      </div>

      <div className="p-8 lg:absolute lg:bottom-0 lg:w-72">
        <div className="bg-cream rounded-3xl p-5 border border-saffron/20">
          <p className="text-[10px] font-bold text-maroon/40 uppercase mb-2 tracking-widest">Need Support?</p>
          <p className="text-xs text-maroon/70 leading-relaxed mb-4">Dedicated concierge available for our elite partners.</p>
          <button className="text-[10px] font-bold text-saffron uppercase border-b border-saffron hover:text-maroon hover:border-maroon transition-all">
            Contact Support
          </button>
        </div>
      </div>
    </div>
  );
};

export default DashboardSidebar;
