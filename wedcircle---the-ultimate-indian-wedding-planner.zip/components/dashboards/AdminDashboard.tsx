
import React, { useState } from 'react';
import { ShieldCheck, Users, Store, ShieldAlert, FileText, Settings } from 'lucide-react';
import DashboardSidebar, { SidebarItem } from './DashboardSidebar';

const ADMIN_NAV_ITEMS: SidebarItem[] = [
  { id: 'stats', label: 'Network Stats', icon: ShieldCheck },
  { id: 'vendors', label: 'Vendor Approvals', icon: Store },
  { id: 'users', label: 'User Management', icon: Users },
  { id: 'reports', label: 'Safety Reports', icon: ShieldAlert },
  { id: 'audit', label: 'System Logs', icon: FileText },
  { id: 'config', label: 'Platform Config', icon: Settings },
];

const AdminDashboard: React.FC = () => {
  const [activeTab, setActiveTab] = useState('stats');

  const renderContent = () => {
    return (
      <div className="space-y-10 animate-in fade-in slide-in-from-bottom-4 duration-500">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          {[
            { label: 'Total Couples', val: '12,450', color: 'bg-blue-500' },
            { label: 'Verified Vendors', val: '2,890', color: 'bg-green-500' },
            { label: 'Gross Shagun (GMV)', val: '₹42Cr', color: 'bg-saffron' },
            { label: 'Pending Approvals', val: '143', color: 'bg-maroon' }
          ].map((stat, i) => (
            <div key={i} className="bg-white p-6 rounded-[24px] shadow-sm border border-cream">
              <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">{stat.label}</p>
              <h4 className="text-2xl font-serif font-bold text-gray-900">{stat.val}</h4>
              <div className={`h-1 w-12 ${stat.color} rounded-full mt-4`}></div>
            </div>
          ))}
        </div>

        <div className="bg-white rounded-[32px] p-10 shadow-xl border border-cream">
          <div className="flex justify-between items-center mb-8">
            <h3 className="text-xl font-serif font-bold text-maroon">Bharosa Badge Verifications</h3>
            <button className="text-xs font-bold text-saffron uppercase border-b border-saffron">View All Requests</button>
          </div>
          
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="flex items-center justify-between p-6 bg-cream/10 rounded-2xl border border-gray-50 hover:border-saffron/20 transition-all">
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 rounded-full bg-maroon/10 flex items-center justify-center">
                    <Store className="text-maroon" />
                  </div>
                  <div>
                    <p className="font-bold text-gray-900">Grand Heritage Venue {i}</p>
                    <p className="text-xs text-gray-400 italic">Submitted documentation 2 hours ago</p>
                  </div>
                </div>
                <div className="flex space-x-3">
                  <button className="px-5 py-2 bg-green-500 text-white text-[10px] font-bold rounded-lg uppercase tracking-widest shadow-md">Approve</button>
                  <button className="px-5 py-2 bg-gray-100 text-gray-500 text-[10px] font-bold rounded-lg uppercase tracking-widest">Reject</button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="pt-20 bg-cream min-h-screen flex flex-col lg:flex-row">
      <DashboardSidebar 
        items={ADMIN_NAV_ITEMS} 
        activeItem={activeTab} 
        setActiveItem={setActiveTab} 
        title="Admin Panel" 
        roleIcon={ShieldCheck}
      />
      <div className="flex-1 overflow-y-auto bg-gray-50/50">
        <div className="max-w-6xl mx-auto p-6 lg:p-12">
          {renderContent()}
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
