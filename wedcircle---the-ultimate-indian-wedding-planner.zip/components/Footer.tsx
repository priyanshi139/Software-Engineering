
import React from 'react';
import { Facebook, Instagram, Twitter, Mail, Phone, Heart } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-[#1a0000] text-cream py-20 px-4">
      <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-12">
        <div className="space-y-6">
          <div className="flex items-center">
            <div className="w-8 h-8 bg-saffron rounded-full flex items-center justify-center mr-2">
              <Heart className="text-maroon w-5 h-5 fill-current" />
            </div>
            <span className="text-2xl font-serif font-bold tracking-tight text-white">
              Wed<span className="text-saffron">Circle</span>
            </span>
          </div>
          <p className="text-sm text-cream/60 leading-relaxed italic">
            "Your journey to the perfect union." <br />
            Transforming Indian weddings with technology and tradition since 2024.
          </p>
          <div className="flex space-x-4">
            <a href="#" className="p-2 bg-white/5 rounded-full hover:bg-saffron hover:text-maroon transition-all"><Instagram size={18} /></a>
            <a href="#" className="p-2 bg-white/5 rounded-full hover:bg-saffron hover:text-maroon transition-all"><Facebook size={18} /></a>
            <a href="#" className="p-2 bg-white/5 rounded-full hover:bg-saffron hover:text-maroon transition-all"><Twitter size={18} /></a>
          </div>
        </div>

        <div>
          <h4 className="text-saffron font-bold mb-6 text-sm uppercase tracking-widest">Company</h4>
          <ul className="space-y-4 text-sm text-cream/80">
            <li><a href="#" className="hover:text-saffron transition-colors">Our Story</a></li>
            <li><a href="#" className="hover:text-saffron transition-colors">Careers in Weddings</a></li>
            <li><a href="#" className="hover:text-saffron transition-colors">The Shaadi Blog</a></li>
            <li><a href="#" className="hover:text-saffron transition-colors">Terms of Service</a></li>
          </ul>
        </div>

        <div>
          <h4 className="text-saffron font-bold mb-6 text-sm uppercase tracking-widest">For Vendors</h4>
          <ul className="space-y-4 text-sm text-cream/80">
            <li><a href="#" className="hover:text-saffron transition-colors">List your Business</a></li>
            <li><a href="#" className="hover:text-saffron transition-colors">Bharosa Badge Program</a></li>
            <li><a href="#" className="hover:text-saffron transition-colors">Partner Dashboard</a></li>
            <li><a href="#" className="hover:text-saffron transition-colors">Success Stories</a></li>
          </ul>
        </div>

        <div>
          <h4 className="text-saffron font-bold mb-6 text-sm uppercase tracking-widest">Contact Us</h4>
          <ul className="space-y-4 text-sm text-cream/80">
            <li className="flex items-center"><Phone size={16} className="mr-3 text-saffron" /> +91 98765 43210</li>
            <li className="flex items-center"><Mail size={16} className="mr-3 text-saffron" /> support@wedcircle.in</li>
            <li className="mt-6 p-4 bg-maroon/50 rounded-xl border border-saffron/20">
              <p className="text-xs text-saffron font-bold mb-1 uppercase tracking-tighter">Office</p>
              <p className="text-xs">Level 4, Heritage House, Connaught Place, New Delhi - 110001</p>
            </li>
          </ul>
        </div>
      </div>
      
      <div className="max-w-7xl mx-auto mt-20 pt-8 border-t border-white/10 flex flex-col md:flex-row justify-between items-center gap-4 text-xs text-cream/40">
        <p>© 2024 WedCircle Technologies Private Limited. All Rights Reserved.</p>
        <p>Made with ❤️ in India for the world's most beautiful weddings.</p>
      </div>
    </footer>
  );
};

export default Footer;
