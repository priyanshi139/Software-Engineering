
import React from 'react';
import { Calendar, UserCheck, CreditCard, Music, PartyPopper } from 'lucide-react';

const steps = [
  {
    title: 'Dream & Budget',
    desc: 'Set your "Shagun" limit and choose your vibe.',
    icon: <Calendar className="w-6 h-6" />,
    color: 'bg-maroon/10 text-maroon'
  },
  {
    title: 'Discover Vendors',
    desc: 'Browse verified artists with our Bharosa Badge.',
    icon: <UserCheck className="w-6 h-6" />,
    color: 'bg-saffron/10 text-saffron'
  },
  {
    title: 'Request Quotes',
    desc: 'Get "Thali" rates and custom packages.',
    icon: <CreditCard className="w-6 h-6" />,
    color: 'bg-maroon/10 text-maroon'
  },
  {
    title: 'Book & Confirm',
    desc: 'Secure your dates with ease.',
    icon: <Music className="w-6 h-6" />,
    color: 'bg-saffron/10 text-saffron'
  },
  {
    title: 'Celebrate!',
    desc: 'Enjoy your seamless, beautiful wedding.',
    icon: <PartyPopper className="w-6 h-6" />,
    color: 'bg-maroon/10 text-maroon'
  }
];

const PlanningFlow: React.FC = () => {
  return (
    <section className="py-20 px-4 bg-cream overflow-hidden">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-5xl font-serif text-maroon mb-4">How it Works</h2>
          <div className="w-24 h-1 bg-saffron mx-auto rounded-full"></div>
          <p className="mt-4 text-gray-600 max-w-xl mx-auto">From Roka to Reception, we guide you through every milestone.</p>
        </div>

        <div className="relative">
          {/* Connector Line (Desktop) */}
          <div className="hidden lg:block absolute top-1/2 left-0 w-full h-0.5 border-t-2 border-dashed border-saffron/30 -translate-y-1/2 z-0"></div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8 relative z-10">
            {steps.map((step, idx) => (
              <div key={idx} className="group flex flex-col items-center text-center">
                <div className={`w-16 h-16 rounded-full flex items-center justify-center mb-6 shadow-xl transition-all group-hover:scale-110 group-hover:shadow-saffron/20 border-2 border-white ${step.color}`}>
                  {step.icon}
                </div>
                <div className="absolute top-0 right-0 text-6xl font-serif text-maroon/5 -z-10 select-none">
                  0{idx + 1}
                </div>
                <h3 className="text-xl font-bold text-gray-800 mb-2">{step.title}</h3>
                <p className="text-sm text-gray-500 leading-relaxed px-4">{step.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default PlanningFlow;
