
import { VendorCategory, Vendor } from './types';

export const APP_NAME = "WedCircle";

export const SAMPLE_VENDORS: Vendor[] = [
  {
    id: '1',
    name: 'Saffron Spices Catering',
    category: VendorCategory.CATERING,
    rating: 4.8,
    reviews: 124,
    location: 'South Delhi',
    priceRange: '₹₹₹',
    image: 'https://images.unsplash.com/photo-1555244162-803834f70033?w=800&q=80',
    isVerified: true,
    thaliPrice: '₹1,200/Plate'
  },
  {
    id: '2',
    name: 'Royal Frames Photography',
    category: VendorCategory.PHOTOGRAPHY,
    rating: 4.9,
    reviews: 89,
    location: 'Mumbai, Bandra',
    priceRange: '₹₹₹₹',
    image: 'https://images.unsplash.com/photo-1519741497674-611481863552?w=800&q=80',
    isVerified: true,
    specialty: 'Cinematic Weddings'
  },
  {
    id: '3',
    name: 'Glow by Jhanvi',
    category: VendorCategory.MAKEUP,
    rating: 4.7,
    reviews: 56,
    location: 'Bangalore, Indiranagar',
    priceRange: '₹₹',
    image: 'https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?w=800&q=80',
    isVerified: false,
    specialty: 'Bridal Airbrush'
  },
  {
    id: '4',
    name: 'The Grand Mahal',
    category: VendorCategory.VENUE,
    rating: 5.0,
    reviews: 210,
    location: 'Jaipur',
    priceRange: '₹₹₹₹₹',
    image: 'https://images.unsplash.com/photo-1542667593-47530661218d?w=800&q=80',
    isVerified: true,
    specialty: 'Palace Weddings'
  }
];
